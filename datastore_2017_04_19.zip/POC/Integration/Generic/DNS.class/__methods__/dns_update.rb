#dns_update
#Jason Ritenour
#April 19, 2017
# This method uses IO.popen to call nsdupate to create/update DNS A records on BIND platforms.  

vm=$evm.root['vm']
hostname=vm.name
domain=".nova.local"
fqdn=hostname+domain
ip=vm.ipaddresses[0]

dnsserver        = Resolv.getaddress(dnsserver) rescue nil 
  IO.popen("nsupdate -y #{dnskey}:#{dnssecret} -v", 'r+') do |f|
   f.puts("server #{dnsserver}")
   if delete == 't' 
    f.puts("update delete #{fqdn} A #{ip}")
    $evm.log("info","IAAS: #{@method} DNS update delete #{name} #{ip} ") 
   else
    f.puts("update add #{fqdn} 180 A #{ip}")  
    $evm.log("info","IAAS: #{@method} DNS update add #{name} #{ip}")  
   end  
   f.puts("send")
   f.close_write
  end
