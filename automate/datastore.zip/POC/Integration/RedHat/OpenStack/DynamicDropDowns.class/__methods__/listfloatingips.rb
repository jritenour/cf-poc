begin

  def dump_root()  
    $evm.log(:info, "Root:<$evm.root> Begin $evm.root.attributes")  
    $evm.root.attributes.sort.each { |k, v| $evm.log(:info, "Root:<$evm.root> Attribute - #{k}: #{v}")}  
    $evm.log(:info, "Root:<$evm.root> End $evm.root.attributes")  

  end  

    attributes = $evm.root.attributes
  vm_name = attributes['dialog_option_1_vm_name']  
  
dump_root
#$evm.vmdb(:miq_provision).all.detect  { |task| task.get_option(:floating_ip_address) == 20000000000030 && task.state != 'finished'  }

provnet=$evm.vmdb(:cloud_tenant).find(20000000000001)
ip_hash = {}
provnet.floating_ips.each do |floatip|
ip_hash[floatip.id] = "#{floatip.address}" if floatip.status == "DOWN"
end

prog=$evm.vmdb(:miq_provision).where(:state=>['pending','queued','active'])
if prog != []
float=prog.find_all { |task| task.get_option(:floating_ip_address)}
array=float.map { |task| task.get_option(:floating_ip_address)}
ip=array.map(&:to_i)

ip.each do |val|
  $evm.log(:info, "Removing floating IP #{val} from the pool.")
#ip=float.last.get_option(:floating_ip_address)
#int=ip.to_i
ip_hash.delete(val)
end
end


#tasks_tab = $evm.vmdb(:miq_provision).where(:state=>['pending','queued','active']).sort_by{|hash| hash.created_on}
#if tasks_tab!=nil
#$evm.log(:info, "found unfished task #{tasks_tab}")
#ip=tasks_tab.get_option(:floating_ip_address)
#ip_hash.delete(ip)
#end
$evm.object['values'] = ip_hash
  if $evm.root['dialog_float_ip_checkbox'] == 't'
    $evm.object['visible'] = true
  else
    $evm.object['visible'] = false
  end



$evm.log(:info, "Dropdown Values Are #{$evm.object['values'].inspect}")

end

