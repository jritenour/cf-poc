begin

  def dump_root()  
    $evm.log(:info, "Root:<$evm.root> Begin $evm.root.attributes")  
    $evm.root.attributes.sort.each { |k, v| $evm.log(:info, "Root:<$evm.root> Attribute - #{k}: #{v}")}  
    $evm.log(:info, "Root:<$evm.root> End $evm.root.attributes")  

  end  

dump_root
  attributes = $evm.root.attributes
  float = attributes['dialog_option_1_floating_ip_address']  

ip=$evm.vmdb(:floating_ip).find("#{float}")
name=ip.address
  
    list_values = {  
    'sort_by' => :none,  
    'data_type'  => :string,  
    'required'   => false,  
    'values'     => [[ name, name ]],  
    }  
  $evm.log(:info, "Dynamic drop down values: Names drop-down: [#{list_values}]")   
  list_values.each { |k,v| $evm.object[k] = v }  

$evm.log(:info, "Dropdown Values Are #{$evm.object['values'].inspect}")

end
